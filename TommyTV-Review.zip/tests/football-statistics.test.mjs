import assert from "node:assert/strict";
import test from "node:test";
import { calculatePlayerStats } from "../app/football-statistics.mjs";

test("credits one completed pass to passer, receiver, and tackler without rushing yards", () => {
  const stats = calculatePlayerStats([{ team: "home", playType: "Pass", passerNumber: "5", receiverNumber: "68", passResult: "Complete", yards: 40, details: { tacklers: ["66"] } }]);
  assert.deepEqual({ ...stats.get("home-5") }, { team: "home", number: "5", plays: 1, yards: 40, rushingYards: 0, passingYards: 40, receivingYards: 0, attempts: 1, completions: 1, receptions: 0, interceptionsThrown: 0, tackles: 0, touchdowns: 0 });
  assert.equal(stats.get("home-68").receptions, 1);
  assert.equal(stats.get("home-68").receivingYards, 40);
  assert.equal(stats.get("away-66").tackles, 1);
});

test("credits incomplete and intercepted passes as attempts but not completions", () => {
  const stats = calculatePlayerStats([
    { team: "away", playType: "Pass", passerNumber: "4", passResult: "Incomplete", yards: 0 },
    { team: "away", playType: "Pass", passerNumber: "4", passResult: "Interception", yards: 0 },
    { team: "away", playType: "Run", playerNumber: "21", yards: 9 },
  ]);
  assert.equal(stats.get("away-4").attempts, 2);
  assert.equal(stats.get("away-4").completions, 0);
  assert.equal(stats.get("away-4").interceptionsThrown, 1);
  assert.equal(stats.get("away-21").rushingYards, 9);
});
