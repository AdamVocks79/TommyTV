export function calculatePlayerStats(plays) {
  const stats = new Map();
  const credit = (team, number, values) => {
    if (!number) return;
    const key = `${team}-${number}`;
    const current = stats.get(key) ?? {
      team, number, plays: 0, yards: 0, rushingYards: 0, passingYards: 0,
      receivingYards: 0, attempts: 0, completions: 0, receptions: 0,
      interceptionsThrown: 0, tackles: 0, touchdowns: 0,
    };
    for (const [field, amount] of Object.entries(values)) current[field] += amount;
    stats.set(key, current);
  };

  for (const play of plays) {
    const offense = play.team ?? "home";
    const defense = offense === "home" ? "away" : "home";
    if (play.playType === "Pass" && play.passerNumber) {
      const complete = play.passResult === "Complete";
      credit(offense, play.passerNumber, {
        plays: 1, attempts: 1, completions: complete ? 1 : 0,
        interceptionsThrown: play.passResult === "Interception" ? 1 : 0,
        passingYards: complete ? Number(play.yards || 0) : 0,
        yards: complete ? Number(play.yards || 0) : 0,
      });
      if (complete && play.receiverNumber) credit(offense, play.receiverNumber, {
        plays: 1, receptions: 1, receivingYards: Number(play.yards || 0),
        yards: Number(play.yards || 0), touchdowns: play.tag === "TOUCHDOWN" ? 1 : 0,
      });
    } else if (play.playerNumber) credit(offense, play.playerNumber, {
      plays: 1, yards: Number(play.yards || 0),
      rushingYards: play.playType === "Run" ? Number(play.yards || 0) : 0,
      touchdowns: play.tag === "TOUCHDOWN" ? 1 : 0,
    });
    for (const tackler of play.details?.tacklers ?? []) credit(defense, tackler, { tackles: 1 });
  }
  return stats;
}
